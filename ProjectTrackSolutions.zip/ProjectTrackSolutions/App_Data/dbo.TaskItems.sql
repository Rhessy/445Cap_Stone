﻿CREATE TABLE [dbo].[TaskItems] (
    [Id]                 INT            IDENTITY (1, 1) NOT NULL,
    [Status]             INT            NOT NULL,
    [DepartmentId]       INT            NOT NULL,
    [IsMandate]          BIT            NOT NULL,
    [MandateComment]     NVARCHAR (25)  NULL,
    [Action]             NVARCHAR (250) NULL,
    [IT_Project_Number]  INT            NOT NULL,
    [LastModifiedDate]   DATETIME       NOT NULL,
    [CreatedDate]        DATETIME       NOT NULL,
    [CompletedDate]      DATETIME       NOT NULL,
    [StartDate]          DATETIME       NOT NULL,
    [OtherDepartment_Id] INT            NULL,
    [Item_Number]      INT            NOT NULL,
    CONSTRAINT [PK_dbo.TaskItems] PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_dbo.TaskItems_dbo.Departments_DepartmentId] FOREIGN KEY ([DepartmentId]) REFERENCES [dbo].[Departments] ([Id]) ON DELETE CASCADE,
    CONSTRAINT [FK_dbo.TaskItems_dbo.Departments_Department_Id] FOREIGN KEY ([OtherDepartment_Id]) REFERENCES [dbo].[Departments] ([Id])
);


GO
CREATE NONCLUSTERED INDEX [IX_DepartmentId]
    ON [dbo].[TaskItems]([DepartmentId] ASC);


GO
CREATE NONCLUSTERED INDEX [IX_OtherDepartment_Id]
    ON [dbo].[TaskItems]([OtherDepartment_Id] ASC);


GO
CREATE NONCLUSTERED INDEX [IX_Department_Id]
    ON [dbo].[TaskItems]([Item_Number] ASC);

